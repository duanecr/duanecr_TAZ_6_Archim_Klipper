/*
  blinkm.h
  Library header file for BlinkM library
 */

#include "Arduino.h"
#include "Wire.h"

void SendColors(byte red, byte grn, byte blu);
