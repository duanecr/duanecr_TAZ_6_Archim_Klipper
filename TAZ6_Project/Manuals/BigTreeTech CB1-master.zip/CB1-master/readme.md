
# OS image
* The latest system image is [here](https://github.com/bigtreetech/CB1/releases)
* The source code is [here](https://github.com/bigtreetech/CB1-Kernel)


# Note
## Here’s BIGTREETECH! For Makers, by makers!
* We appreciate all of your support to BIGTREETECH! To offer an excellent experience of creation to every makers,We’re devoted to design and produce high-quality and durable accessories!

## How to contact:
### If you have any technical issue,please don’t hesitate contact us:
* BIGTREETECH: service004@biqu3d.com

### Follow us on social media to get more news:
* Facebook: https://www.facebook.com/BIGTREETECH/
* Twitter: https://twitter.com/BigTreeTech
* Instagram: https://www.instagram.com/bigtreetech_official/
* Official Site: https://bigtree-tech.com/

## Purchase link:
* M4P/M8P/CB1: https://www.biqu.equipment/collections/control-board/products/manta-m4p-m8p
